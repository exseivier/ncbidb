
## NCBI-DB: A protein, genes and genomes databse manager
---
Command line interface with options to manage NCBI dtabases of proteins, genes and genomes.
